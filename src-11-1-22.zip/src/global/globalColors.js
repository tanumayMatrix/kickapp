const COLORS = {
  yellow: '#F88028',
  darkBlue:'#668671',
  lightGreen:'#ABBDBE',
  lightBlue:'#466F73',
  darkGrey:'#4D4D4D'
  // your colors
};
export default COLORS;
